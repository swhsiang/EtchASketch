#include "stm32f0xx.h"
#include "stm32f0_discovery.h"
#include <string.h>

#define SCL 1
#define SDI 2
#define SS 4
#define SPI_DELAY 400

void init_lcd(void);
void display1(const char *);
void display2(const char *);

void init_pwm(void);
void update_freq(int f);
void update_rgb(int r, int g, int b);
void nano_wait(int t);

void init_keypad(void);
void scan_keypad(void);

int main(void)
{
    init_keypad();
    init_lcd();
    init_pwm();
    update_rgb(1,1,1);
    update_freq(8);
    display1("LED: 010101");
    display2("FREQ: 000008");
    scan_keypad();
}

static void sendbit(int b)
{
	GPIOC->BRR = SCL;
	GPIOC->BSRR = b ? SDI : (SDI << 16);
	nano_wait(SPI_DELAY);
	GPIOC->BSRR = SCL;
	nano_wait(SPI_DELAY);
}

static void sendbyte(char b)
{
	int x;
	for(x=8; x>0; x--)
	{
		sendbit(b & 0x80);
		b <<= 1;
	}
}

static void cmd(char b)
{
	GPIOC->BRR = SS;
	nano_wait(SPI_DELAY);
	sendbit(0);
	sendbit(0);
	sendbyte(b);
	nano_wait(SPI_DELAY);
	GPIOC->BSRR = SS;
	nano_wait(SPI_DELAY);
}

void init_keypad(void)
{
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOCEN;

	// initialize PA4, PA5, PA6, and PA7 as GPIO outputs and set their outputs to zero
	GPIOA->MODER &= ~0xff00;
	GPIOA->MODER |= 0x5500;

	GPIOA->MODER &= ~0xfc;
	GPIOA->MODER |= 0xa8;

	GPIOA->ODR &= 0xffff0000;

	GPIOA->AFR[0] &= ~0xfff0;
	GPIOA->AFR[0] |= 0x2220;

	GPIOA->PUPDR = 0xa8;

	RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
	TIM2->PSC = 1 - 1;
	TIM2->ARR = 0xffffffff;

	// initialize channel 2
	TIM2->CCMR1 &= ~TIM_CCMR1_CC2S;
	TIM2->CCMR1 |= TIM_CCMR1_CC2S_0;
	TIM2->CCMR1 &= ~TIM_CCMR1_IC2F;
	TIM2->CCMR1 &= ~TIM_CCMR1_IC2PSC;


	// initialize channel 3
	TIM2->CCMR2 &= ~TIM_CCMR2_CC3S;
	TIM2->CCMR2 |= TIM_CCMR2_CC3S_0;
	TIM2->CCMR2 &= ~TIM_CCMR2_IC3F;
	TIM2->CCMR2 &= ~TIM_CCMR2_IC3PSC;


	// initialize channel 4
	TIM2->CCMR2 &= ~TIM_CCMR2_CC4S;
	TIM2->CCMR2 |= TIM_CCMR2_CC4S_0;
	TIM2->CCMR2 &= ~TIM_CCMR2_IC4F;
	TIM2->CCMR2 &= ~TIM_CCMR2_IC4PSC;


	TIM2->CCER &= ~(TIM_CCER_CC2P|TIM_CCER_CC2NP|TIM_CCER_CC3P|TIM_CCER_CC3NP|TIM_CCER_CC4P|TIM_CCER_CC4NP);
	TIM2->CCER |= (TIM_CCER_CC2E | TIM_CCER_CC3E | TIM_CCER_CC4E);
	TIM2->DIER |= (TIM_DIER_CC2IE | TIM_DIER_CC3IE | TIM_DIER_CC4IE);


	TIM2->CR1 |= TIM_CR1_CEN;
	NVIC->ISER[0] = 1 << TIM2_IRQn;
}

void init_pwm(void)
{
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOCEN;

	// initialize PA8, PA9, PA10 as GPIO outputs and set their outputs to zero
	GPIOA->MODER &= ~0x3f0000;
	GPIOA->MODER |= 0x2a0000;

	GPIOA->AFR[1] &= ~0xf;
	GPIOA->AFR[1] |= 0x222;

	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    TIM1->PSC = 480-1;
    TIM1->ARR = 100-1;
    TIM1->CCR1 = 4;
    TIM1->CCR2 = 4;
    TIM1->CCR3 = 4;

    TIM1->CCMR1 |=  TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1PE;
    TIM1->CCMR1 |=  TIM_CCMR1_OC2M_2 | TIM_CCMR1_OC2M_1 | TIM_CCMR1_OC2PE;
    TIM1->CCMR2 |=  TIM_CCMR2_OC3M_2 | TIM_CCMR2_OC3M_1 | TIM_CCMR2_OC3PE;

    // initialize pins for TIM1_CH1, TIM1_CH2, TIM1_CH3
    TIM1->CCER |= TIM_CCER_CC1E | TIM_CCER_CC2E | TIM_CCER_CC3E;

    TIM1->BDTR |= TIM_BDTR_MOE;
    TIM1->CR1 |= TIM_CR1_CEN;
}

void update_freq(int freq)
{
	TIM1->PSC = (48000000.0)/(freq*100.0) - 1;
}

void update_rgb(int r, int g, int b)
{
	TIM1->CCR1 = r;
	TIM1->CCR2 = g;
	TIM1->CCR3 = b;
}

static int row = 0;
void scan_keypad(void)
{
	for(;;)
		for(row=1; row<5; row++)
		{
			GPIOA->BSRR = 1 << (row+3);
			nano_wait(10000000);
			GPIOA->BRR = 0xf0;
			nano_wait( 1000000);
		}
}

static void press(char c)
{
	static int offset = 0;
	static int r,g,b;
	static int freq = 0;
	static char ledline[17];
	static char freqline[17];
	static int entry = ' ';
	if(c == '*')
	{
		if (entry != ' ') return;
		entry = '*';
		strcpy(ledline, "LED: _");
		display1(ledline);
		return;
	}
	if(c == '#')
	{
		if (entry != ' ') return;
		entry = '#';
		strcpy(freqline, "FREQ: _");
		display2(freqline);
		return;
	}
	if (entry == '*')
	{
		ledline[5 + offset] = c;
		if (offset < 5)
			ledline[5 + offset + 1] = '_';
		display1(ledline);
		switch(offset)
		{
			case 0: r = 10 * (c-'0'); 	offset++; break;
			case 1: r +=  (c - '0'); 	offset++; break;
			case 2: g = 10 * (c-'0'); 	offset++; break;
			case 3: g += (c - '0'); 	offset++; break;
			case 4: b = 10 * (c-'0'); 	offset++; break;
			case 5: b += (c - '0'); 	offset = 0; update_rgb(r,g,b); entry=' '; break;
		}
	}
	if (entry == '#')
	{
		freqline[6+offset] = c;
		if (offset < 5)
			freqline[6 + offset +1] = '_';
		display2(freqline);
		freq = freq * 10 + (c - '0');
		offset += 1;
		if (offset == 6)
		{
			if (freq < 8)
			{
				freq = 8;
				display2("FREQ: 000008");
			}
			if (freq > 480000)
			{
				freq = 480000;
				display2("FREQ: 480000");
			}
			offset = 0;
			entry = ' ';
			update_freq(freq);
			freq = 0;
		}
	}
}

void TIM2_IRQHandler()
{
	if ((TIM2->SR & TIM_SR_UIF) != 0)
	{
		TIM2->SR &= ~TIM_SR_UIF;
		return;
	}
	if (TIM2->SR & TIM_SR_CC2IF)
	{
		switch(row)
		{
			case 1: press('1'); break;
			case 2: press('4'); break;
			case 3: press('7'); break;
			case 4: press('*'); break;
		}
	}
	if (TIM2->SR & TIM_SR_CC3IF)
	{
		switch(row)
		{
			case 1: press('2'); break;
			case 2: press('5'); break;
			case 3: press('8'); break;
			case 4: press('0'); break;
		}
	}
	if(TIM2->SR & TIM_SR_CC4IF)
	{
		switch(row)
		{
			case 1: press('3'); break;
			case 2: press('6'); break;
			case 3: press('9'); break;
			case 4: press('#'); break;
		}
	}

	nano_wait(10 * 1000 * 1000);
	while((GPIOA->IDR & 0xf) != 0)
		;
	nano_wait(10 * 1000 * 1000);

	int __attribute((unused))useless;
	useless = TIM2->CCR2;
	useless = TIM2->CCR3;
	useless = TIM2->CCR4;
	return;
}

static void data(char b)
{
	GPIOC->BRR = SS;
	nano_wait(SPI_DELAY);
	sendbit(1);
	sendbit(0);
	sendbyte(b);
	nano_wait(SPI_DELAY);
	GPIOC->BSRR = SS;
	nano_wait(SPI_DELAY);
}

void init_lcd(void)
{
	RCC->AHBENR |= RCC_AHBENR_GPIOCEN;

	GPIOC->ODR |= 7;
	GPIOC->MODER &= ~0x3f;
	GPIOC->MODER |= 0x15;

	nano_wait(100000000);
	cmd(0x38);
	cmd(0x0c);
	cmd(0x01);
	nano_wait(6200000);
	cmd(0x02);
	cmd(0x06);
}

void display1(const char *s)
{
	cmd(0x02);
	int len;
	for(len=0; len<16; len +=1)
	{
		if(s[len] == '\0')
			break;
		data(s[len]);
	}
}

void display2(const char *s)
{
	cmd(0xc0);
	int len;
	for(len=0; len<16; len +=1)
	{
		if(s[len] == '\0')
			break;
		data(s[len]);
	}
}
